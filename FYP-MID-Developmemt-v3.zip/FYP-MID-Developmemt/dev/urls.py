from django.contrib import admin

from django.urls import path
from dev import views
urlpatterns = [
    path('',views.index),
    path('login/', views.login),
    path('callback/', views.callback),
    path('dashboard/', views.dashboard)
]
