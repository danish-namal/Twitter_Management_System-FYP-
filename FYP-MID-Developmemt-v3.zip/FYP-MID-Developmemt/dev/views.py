from django.shortcuts import render,redirect
import tweepy

API_KEY = "f6S0PiymKaQj1UbAC0YDbXTEc"
API_SECRET = "z2ijOUfKhKVaUh7LYVkhLlaOB5wv1lDBuVrHihXjLjkdQRKN3R"
# ACCESS_TOKEN = "1258339053478567936-BLOqKQxJfQknw2SDhe5MnTlr6RuMcI"
# ACCESS_TOKEN_SECRET = "QKk2vfGxvZRZW8EtGAquFDjhg18PKwmaLg4cVex2z4wag"
CALLBACK_URL = "http://127.0.0.1:8000/callback"
AUTH = tweepy.OAuthHandler(API_KEY, API_SECRET, callback=CALLBACK_URL)


def index(request):
    return render(request,"index.html")


def login(request):
    auth_url = AUTH.get_authorization_url()
    request.session['request_token'] = AUTH.request_token
    return redirect(auth_url)


def callback(request):
    verifier = request.GET.get('oauth_verifier')
    request_token = request.session.pop('request_token', None)
    if not verifier or not request_token:
        pass
    AUTH.request_token = request_token
    AUTH.get_access_token(verifier)
    access_token = AUTH.access_token
    access_token_secret = AUTH.access_token_secret
    request.session['access_token'] = access_token
    request.session['access_token_secret'] = access_token_secret
    return redirect('/dashboard')


def dashboard(request):
    api = tweepy.API(AUTH, wait_on_rate_limit=True)
    r=api.verify_credentials()
    data={
        "FollowerCount":r.followers_count,
        "FollowingCount":r.friends_count
        }
    return render(request, 'dashboard/dashboard.html', data)