from django.contrib import admin

from django.urls import path
from dev import views
urlpatterns = [
    path('',views.index),
    path('login/', views.login),
    path('callback/', views.callback),
    path('dashboard/', views.dashboard),
    path('follow/', views.follow),
    path('followers/', views.followers),
    path('search_users/<search_query>', views.search_users),
    path('follow_user/', views.follow_user)
]
