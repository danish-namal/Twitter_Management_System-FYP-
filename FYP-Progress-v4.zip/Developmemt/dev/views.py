from django.shortcuts import render, redirect
from django.http import JsonResponse
import tweepy

API_KEY = "bQyHCwwd8X1tyjtNoJNABEnec"
API_SECRET = "3KTivA5uUFb4k6rzyNZZqJv4vRMf3yOCCmTMs2ixXRb8Mg6hZ0"
# ACCESS_TOKEN = "1258339053478567936-BLOqKQxJfQknw2SDhe5MnTlr6RuMcI"
# ACCESS_TOKEN_SECRET = "QKk2vfGxvZRZW8EtGAquFDjhg18PKwmaLg4cVex2z4wag"
CALLBACK_URL = "http://127.0.0.1:8000/callback"
AUTH = tweepy.OAuthHandler(API_KEY, API_SECRET, callback=CALLBACK_URL)


def index(request):
    return render(request, "index.html")


def login(request):
    auth_url = AUTH.get_authorization_url()
    request.session['request_token'] = AUTH.request_token
    return redirect(auth_url)


def callback(request):
    verifier = request.GET.get('oauth_verifier')
    request_token = request.session.pop('request_token', None)
    if not verifier or not request_token:
        pass
    AUTH.request_token = request_token
    AUTH.get_access_token(verifier)
    access_token = AUTH.access_token
    access_token_secret = AUTH.access_token_secret
    request.session['access_token'] = access_token
    request.session['access_token_secret'] = access_token_secret
    return redirect('/dashboard')


def dashboard(request):
    api = tweepy.API(AUTH, wait_on_rate_limit=True)
    r = api.verify_credentials()
    followers=api.get_followers()
    followerslist=[]
    for follower in followers:
        followerslist.append(follower.screen_name)

    recentFollowers={}
    for follower in followers:
        recentFollowers.update({
            follower.id : {
                "profile_image_url":follower.profile_image_url,
                "name":follower.name,
                "screen_name":follower.screen_name,
                "followers_count":follower.followers_count,
                "following": follower.friends_count,
                "follow_back": 100 if round((follower.friends_count/(1 if follower.followers_count==0 else follower.followers_count))*100, 1)>=100 else round((follower.friends_count/(1 if follower.followers_count==0 else follower.followers_count))*100, 1),
                "created_at": str(follower.created_at)[0:11]
                }
            })

    friendship= api.get_friends()
    friendslist=[]
    for i in friendship:
        friendslist.append(i.screen_name)

    Non_followers = len([item for item in friendslist if item not in followerslist])
    data = {
        "FollowerCount": r.followers_count,
        "FollowingCount": r.friends_count,
        "NonFollowers": Non_followers,
        "follow_back": 100 if round((r.friends_count/(1 if r.followers_count==0 else r.followers_count))*100, 1)>=100 else round((r.friends_count/(1 if r.followers_count==0 else r.followers_count))*100, 1),
        "RecentFollowers": recentFollowers
    }
    return render(request, 'dashboard/dashboard.html', data)


def follow(request):
    api = tweepy.API(AUTH, wait_on_rate_limit=True)
    r = api.verify_credentials()
    data = {
        "FollowerCount": r.followers_count,
        "FollowingCount": r.friends_count,
    }
    return render(request, 'dashboard/follow.html', data)


def followers(request):
    api = tweepy.API(AUTH)
    followers=api.get_followers()
    followerslist={}
    for follower in followers:
        followerslist.update({
            follower.id : {
                "profile_image_url":follower.profile_image_url,
                "name":follower.name,
                "screen_name":follower.screen_name,
                "followers_count":follower.followers_count,
                "following": follower.friends_count,
                "follow_back": 100 if round((follower.friends_count/(1 if follower.followers_count==0 else follower.followers_count))*100, 1)>=100 else round((follower.friends_count/(1 if follower.followers_count==0 else follower.followers_count))*100, 1),
                "created_at": str(follower.created_at)[0:11]
                }
            })
    return render(request, 'dashboard/followers.html', {"data" : followerslist})


def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'


def follow_user(request):
    api = tweepy.API(AUTH)
    if is_ajax(request) and request.method == "POST":
        screen_name = request.POST.get('screen_name')
        try:
            api.create_friendship(screen_name=screen_name)
        except Exception as e:
            return JsonResponse({"error" : e}, status=400)        
    return JsonResponse({"success" : "Follow successfull"}, status=200)


def search_users(request, search_query):
    api = tweepy.API(AUTH, wait_on_rate_limit=True)
    r = api.verify_credentials()
    data = {
        "Users": r.search_users(q=search_query),
    }
    return JsonResponse({"data": data}, status=200)

